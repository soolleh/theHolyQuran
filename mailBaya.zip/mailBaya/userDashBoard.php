<?php
	session_start();
	// $_SESSION["shouldAllow"] = "";
	require_once('files/functions.php');
	if (!empty($_SESSION) && !empty($_SESSION['userName']) && !empty($_SESSION['sessionId'])) {
		$sessionUserName = $_SESSION['userName']; 
		$sessionId = $_SESSION['sessionId'];
		$CheckloginResult = checkLogin($sessionUserName, $sessionId);
		if ($CheckloginResult == 'allow') {
			$_SESSION["shouldAllow"] = true;
			
		}
		else {
			// echo "CheckloginResult id false";
			$_SESSION["shouldAllow"] = false;
		}
	}
	else {
		// echo "seeting shouldAllow to false";
		$_SESSION["shouldAllow"] = false;
	}

	if (isset($_GET['action'])) {
		$action = $_GET['action'];
		if ($action == 'logout') {
			logout();
		}
	}
	if (isset($_SESSION['shouldAllow'])) {
		if ($_SESSION['shouldAllow'] == true) {
			$title = 'Welcome | '.$_SESSION['userName'];
			$footer = 'navbar-fixed-bottom';
		}
		else{
			$title = 'You Must Be Logged In';
			$footer = '';
		}
	
?>
<!DOCTYPE html>
<html>
<html lang="en">
<head>
	<title><?php echo $title; }?></title>
	<meta charset="utf-8">
	<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- *****Style Sheets***** -->
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/logIn.css">
	<link rel="stylesheet" type="text/css" href="css/userDashBoard.css">
	<!-- *****Scripts***** -->
	<script src="js/jquery-2.1.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/script.js"></script>    

</head>
<body style="background-color: #EDDABC;">

 <!-- ********************************************** Header **********************************************-->
<header>
	<div class="container-fluid header-outer-div">
		<div class="container header-inner-div">
			<div class="logo">
				<a href="index.php"><img class="logo-img img-responsive" src="images/logo1.png" width="100" height="100"></a>
					<span class="arabic" dir="rtl" lang="ar"><span class="arabic-text">القران الکریم</span></span>
			</div>
		</div>
	</div>
</header>
<div class="container-fluid">
	<div class="container">
<?php 
	if (isset($_SESSION["shouldAllow"])) {
		if ($_SESSION['shouldAllow'] == true) {
			include_once('files/config.php');
			$dbc = connect();
			$subUserName = $_SESSION['userName'];
			$sql = "SELECT * FROM members WHERE userName = '".$subUserName."'" 
			."OR userEmail = '" .$subUserName."'";
			$qResult = mysqli_query($dbc, $sql);
			if ($qResult) {
				$userDetails = mysqli_fetch_assoc($qResult);
				$today = $userDetails['userRegisteredOn'];
				echo "Name : " . $userDetails['fullName']."<br>"
				."User Name : " .$userDetails['userName']."<br>"
			 	."User Registered On : ".date("F j, Y, g:i a",$today);  
			 	echo "<br>";
			 	
			}
			// echo '<a href="files/logout.php">Click To Log Out</a>';
			echo "<a href='userDashBoard.php?action=logout'>Click To Log Out</a>";
		}
		else {
			// echo 'shoulallow is not true';
			echo '<br><section><h3 class="text-center"><span class="text-danger bg-danger text-center">You Must Be Looged In To View This Page. <a href="login.php">Click Here To Log In</a></span></h3></section>';
		}
	} 
	else {
			// echo 'shoul allow is not set';
			echo '<br><section><h3 class="text-center"><span class="text-danger bg-danger text-center">You Must Be Looged In To View This Page. <a href="login.php">Click Here To Log In</a></span></h3></section> ';
		}

?>
	</div>
</div>
<br>
<?php 
	if (isset($_SESSION['shouldAllow'])) {
		if ($_SESSION['shouldAllow'] == true) {
			$footer = '';
		}
		else{
			$footer = 'navbar-fixed-bottom';
		} ?>
<div class="container-fluid <?php echo $footer; }?>" style="background-color: #112E44;"><br>
	<div class="container footter">
		<footer>
			Developed By Soleh Firdous Asime 
			<br> Email : soleh.asmie@gmail.com 
			<br> Phone : +91-9018-352236
		</footer> 
	</div><br>
</div>	
</body>
</html>
