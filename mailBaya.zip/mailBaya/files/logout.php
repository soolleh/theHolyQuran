<?php
require_once('config.php');
	session_start();
	// remove all session variables
	session_unset(); 
	$_SESSION = array();

// get session parameters 
$params = session_get_cookie_params();

// Delete the actual cookie. 
setcookie(session_name(),'', time() - 42000, $params["path"], $params["domain"], $params["secure"], $params["httponly"]);

// Destroy session 
// session_destroy();

	// destroy the session 
	session_destroy();
	mysqli_close($dbc);
		ob_start();
		echo "<script>location.assign('../login.php?result=logout success')</script>";
		//header('Location : ../login.php?result=logout success');
		ob_end_flush();
		exit();
?>