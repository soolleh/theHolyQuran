<?php 
		if (isset($_POST['loginBtn']) || isset($_POST['user_name'])) {
			require_once('functions.php');
			ob_start();
			$result = login($_POST); 
			if ($result == 'authenticated') {
				session_start();
				ob_start( );
				header('Location : ../userDashBoard.php?user='.$_SESSION["userName"],  true,  301);
				ob_end_flush();
				exit();
			}
			else{
				ob_start( );
				header('Location : ../login.php?result='.$result,  true,  301);
				ob_end_flush();
				exit();
			}
ob_end_flush();
	}
 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<title>Processing login</title>
 </head>
 <body>
 <h3 style="color: red;">Something Strange happened while logging you in. <a href="../login.php">Please Click Here To login Again</a></h3>
 </body>
 </html>