<?php 
	if (isset($_POST['signUpBtn']) || isset($_POST)) {
		ob_start();
		require_once('functions.php');
		ob_end_flush();
		$result = register($_POST);
		// echo $result;
		if ($result == 'true') {
			ob_start( );
			header('Location : ../login.php?result=true',  true,  301);
			ob_end_flush();
			exit();
		}
		else{
			ob_start( );
			header('Location : ../register.php?result='.$result.'&full_name='.$_POST['full_name'].'&user_name='.$_POST['user_name'].'&user_email='.$_POST['user_email'],  true,  301);
			ob_end_flush();
			exit();
		}
ob_end_flush();
	}
 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<title>Processing Registration......</title>
 </head>
 <body>
 <h3 style="color: red;">Something Strange happened while logging you in. <a href="../register.php">Please Click Here To login Again</a></h3>
 </body>
 </html>