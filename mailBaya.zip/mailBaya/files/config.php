<?php
	header("Content-type: text/html; charset=utf-8");
	DEFINE('DB_USER' , 'root');
	DEFINE('DB_PASSWORD' ,'Soleh@1995');
	DEFINE('DB_HOST','localhost');
	DEFINE('DB_NAME','theholyquran');

	$dbc = @mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME )
	OR die('{"error":{"errorText":"Could not connect to MYSQL Datbase and hence no data received MYSQL error : '.mysqli_connect_error().'"}}');

	// if (mysqli_ping($dbc)) {
 //    	//echo "Our connection is ok!";
	// } 
	// else {
 //  	  echo "Error : " .mysqli_error($dbc);
	// }
	function connect(){
		$dbc = @mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME )
	OR die('{"error":{"errorText":"Could not connect to MYSQL Datbase and hence no data received MYSQL error : '.mysqli_connect_error().'"}}');
		return $dbc;
	}

//Salt Information
//Site Key
	DEFINE('SiteKey','GHDE8c02fUTrINv9e4ELYgslqdWaV7zft}L`8A<U6:q*}}-u%5&l.t)/)dV`}CUy.f&Xj4SuU*Wu6Gcn<MYjUZ~"W>|Eh[GKcE_oi*aJfh9cdQ2.F{6oGT@;5!I-!Q<#');
//NONCE Salt Number Used Once
	DEFINE('NonceSalt', 'fK)$DQ5g<*$4E.)+*#{96,c_P7?G#8MezgH&3PZ!hnvM]_f4Xdkk/`n";TEH>8<9wN`#`d.rQ8bWtQRvRqzMB\p+nVYNbB_x6[\2=78Bp9%x{dRNt&/LX_e3H4?J=ua$');
//Authorization Salt
	DEFINE('AuthSalt','Wy^qeNj`f,U)fze?B#B^Uhg6Ke>}?.6Y$?((hq]*6?C#E\?.7KxBy>bFb<_Y8yp@');

?>