<?php 
	function sanitizeString($data){
	 	// $data =	str_replace("'","",$data);
		// $data =	str_replace("-","",$data);
		$data =	str_replace("OR 1=1","",$data);
		$data =	str_replace("or 1=1","",$data);
		$data =	str_replace("Or 1=1","",$data);
		$data =	str_replace("oR 1=1","",$data);
		// $data =	str_replace("OR","",$data);
		// $data =	str_replace("or","",$data);
		// $data =	str_replace("Or","",$data);
		// $data =	str_replace("oR","",$data);
		// $data = trim($data);
  		// $data = htmlspecialchars($data);
		$data =	str_replace("<script>","",$data);
	    // $data = stripslashes($data);
	    // $data = strip_tags($data);
	    // $data = htmlentities($data);
	    echo $data."<br>";
	    return $data;
	}

	function clean($array){
		return array_map("test_input", $array);
		}

	function hashPassword($password, $nonce){
		$secureHash = hash_hmac('sha512', $password.$nonce, SiteKey);
		return $secureHash;
		}

	function test_input($data) {
	  $data = trim($data);
  	  $data = stripslashes($data);
  	  $data = htmlspecialchars($data);
  	  return $data;
	}

	function validateInputs($data){
		$nameErr = $unameErr = $emailErr ="";
		$name = $uname = $email = "";
		if (empty($data["full_name"])) {
    		$nameErr = "Name is required";
    		return $nameErr;
    		exit();
 		} 
 		else {
    		$name = test_input($data["full_name"]);
    		// check if name only contains letters and whitespace
    		if (!preg_match("/^[a-zA-Z ]*$/",$name)) {
      			$nameErr = "Only letters and white space allowed in name";
      			return $nameErr;
    			exit(); 
    		}
 		}
 		if (empty($data['user_name'])) {
 			$unameErr = "User Name is Required";
 			return $unameErr;
    		exit();
 		}
 		else{
 			if ( !preg_match("/^[a-zA-Z0-9]+$/", $data['user_name'])) {
 				$unameErr = 'Only letters and white space allowed in user name';
 				return $unameErr;
 				exit();
 			}
 		}
  
 		if (empty($data["user_email"])) {
   			$emailErr = "Email is required";
   			return $emailErr;
   			exit();
  		} 
  		else {
   			$email = test_input($data["user_email"]);
    		// check if e-mail address is well-formed
    		if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      			$emailErr = "Invalid Email Format"; 
      			return $emailErr;
      			exit();
    		}
  		}
  		if (empty($nameErr) && empty($emailErr) && empty($unameErr)) {
  			return 'valid';
  		}
	}

	function validateLogInInputs($data){
		$nameErr ="";
		$name ="";
		if (empty($data["user_name"])) {
				$nameErr = "Name is required";
		} 
		else {
			$name = test_input($data["user_name"]);
			// check if name only contains letters and whitespace
			if (!preg_match("/^[a-zA-Z0-9]+$/",$name) && !filter_var($name, FILTER_VALIDATE_EMAIL)) {
	  			$nameErr = "Invalid Format. Try Again"; 
			}
		}

		if (empty($nameErr)) {
			return 'valid';
		}
		else {
			return $nameErr;
			exit();
		}
	}

	function register($post){
		if ($_SERVER["REQUEST_METHOD"] == "POST") {
			header("Content-type: text/html; charset=utf-8");
			require_once('config.php');
			$table = "members";
			$Selectsql = "SELECT * FROM $table WHERE userEmail = '" . $post['user_email'] . "'" ."OR userName 
			= '".$post['user_name']."'";
			$Selectresult = mysqli_query($dbc, $Selectsql);
			if (mysqli_num_rows($Selectresult) == 0) {
				$isValid = validateInputs($post);
				if ($isValid == 'valid') {
					date_default_timezone_set('Asia/Kolkata');
					//These are the fields defined in the table
					$fields = array('fullName', 'userName', 'userPassword', 'userEmail', 'userRegisteredOn');
					//Now break the post array
					$fullName = $post['full_name'];
					$userName = $post['user_name'];
					$userPass = $post['user_password'];
					$userEmail = $post['user_email'];
					date_default_timezone_set('Asia/Kolkata');
					$userRegisteredOn = time();
					//We create the NONCE Using action, username, timestamp and the nonce_salt
					$nonce = md5('registration-'.$userName. $userRegisteredOn. NonceSalt);
					//we hash the password using the hash_password function;
					$userPass = hashPassword($userPass, $nonce);
					//recompile our $values array to be inserted in the database
					$values = array(
									'name' => $fullName,
									'login' => $userName,
									'password'=>$userPass,
									'email'=>$userEmail,
									'date'=> $userRegisteredOn);
					//These are the values from the reg form cleaned using using our clean function
					$values = clean($values);
					//and we insert our data
					$fields = implode(", ", $fields);
					$values = implode("', '", $values);
					$sql = "INSERT INTO $table ($fields) values ('$values');";
					$fields2 = array('userName', 'userEmail', 'securityQuestion', 'securityAnswer', 'tempPass');
					$values2 = array(
										'login' => $userName,
										'email'=>$userEmail,
										'question' => NULL,
										'answer' => NULL,
										'tempPass' => NULL
										);
					$fields2 = implode(", ", $fields2);
					$values2 = implode("', '", $values2);
					$sql .= "INSERT INTO memberoptions ($fields2) values ('$values2')";
					$sqlq = mysqli_multi_query($dbc,$sql);
					if (!$sqlq) {
						$mySqlError = mysqli_error($dbc);
						return 'mySqlError' . $mySqlError;
						exit();
					}
					else {
						// $sqlq2 = mysqli_query($dbc,$sql2);
						// if (!$sqlq2) {
						// 	$mySqlError = mysqli_error($dbc);
						// 	return 'mySqlError' . $mySqlError.'<br>'.$sql2;
						// 	exit();
						// }
						// else{
							return "true";
							mysqli_close($dbc);
							exit();
						//}
					}
				}
				else{
					return $isValid;
					mysqli_close($dbc);
					exit();
				}		
			}
			else 	{
				$Selectsql = "SELECT * FROM $table WHERE userEmail = '" . $post['user_email'] . "'" ;
				$result = mysqli_query($dbc, $Selectsql);
				if (mysqli_num_rows($result) != 0) {
					return 'Entered Email Is Already Registered.Try Another One';
					mysqli_close($dbc);
					exit();
				}
				else{
					return 'Entered User Name Is Already Registered.Try Another One';
					mysqli_close($dbc);
					exit();
				}
			}
		}
	}

	function login($post){
		if ($_SERVER["REQUEST_METHOD"] == "POST") {
			if (!empty($_POST)) {
				header("Content-type: text/html; charset=utf-8");
				//var_dump(get_required_files());
				require_once('config.php');
				$table = "members";
				$isValid = validateLogInInputs($post);
					if ($isValid == 'valid') {
						// date_default_timezone_set('Asia/Kolkata');
						$values = clean($post);
						$submittedUserName = $post['user_name'];
						$submittedPassword = $post['user_password'];
						$sql = "SELECT * FROM $table WHERE userName = '".$submittedUserName."'" 
						."OR userEmail = '" .$submittedUserName."'";
						$qResult = mysqli_query($dbc,$sql);
						if ($qResult) {
							if (mysqli_num_rows($qResult) == 1) {
								$userDetails = mysqli_fetch_assoc($qResult);
								$storedUserName = $userDetails['userName'];
								$storedPassword = $userDetails['userPassword'];
								$stordRegDate = $userDetails['userRegisteredOn'];
								$nonce = md5('registration-'.$storedUserName. $stordRegDate. NonceSalt);
								$submittedPassword = hashPassword($submittedPassword, $nonce);
								if($submittedPassword === $storedPassword){
									$authNonce = md5('cookie-'.$storedUserName . AuthSalt);
									$authId = hashPassword($submittedPassword, $authNonce);
									session_start();
									$_SESSION["userName"] = $userDetails['userName'];
									$_SESSION["sessionId"] = $authId;
									return 'authenticated';
									mysqli_close($dbc);
									exit();
								}
								else{
									return 'You Entered Wrong Details. Try Again';
									mysqli_close($dbc);
									exit();
								}


							
							}
							elseif(mysqli_num_rows($qResult) == 0){
								return "Couldn't Find Any User. Try Again";
								mysqli_close($dbc);
								exit();
							}
							else{
								return 'This Is Strange But We found Duplicate Enteries For Given Details. Sorry You Cannot Proceed Untill It Is Fixed';
								mysqli_close($dbc);
								exit();
							}

						}
						else{
							return 'mySqlError' . mysqli_error($dbc);
							mysqli_close($dbc);
							exit();

						}
						
					
					}
					else{
						return $isValid;
						mysqli_close($dbc);
						exit();
					}
				}
				else{
					echo "Didn't Reciever any POST data";
					exit();
				}
			}

		else {
			return 'not post method';
			exit();
		}
	}

	function checkLogin($sessionUserName, $sessionId){
		header("Content-type: text/html; charset=utf-8");
		$submittedUserName = $sessionUserName;
		$submittedSessionId = $sessionId;
		 require_once('config.php');
		$aql = "SELECT * FROM members WHERE userName = '".$submittedUserName."'";
		$aqlResult = mysqli_query($dbc, $aql);
		if ($aqlResult) {
			if (mysqli_num_rows($aqlResult) == 1) {
				$aqluserDetails = mysqli_fetch_assoc($aqlResult);
				$aqlstoredUserName = $aqluserDetails['userName'];
				$aqlstoredPassword = $aqluserDetails['userPassword'];
				$auth_nonce = md5('cookie-'.$aqlstoredUserName.AuthSalt);
				$auth_id = hashPassword($aqlstoredPassword, $auth_nonce);
				if ($auth_id === $submittedSessionId) {
					mysqli_close($dbc);
					return "allow";
					exit();
				}
				else{
					return 'dont allow';
					mysqli_close($dbc);
					exit();
				}
				
			}
			else{
				return 'dont allow';
				mysqli_close($dbc);
				exit();
			}
		}
		else{
			return 'dont allow';
			mysqli_close($dbc);
			exit();
		}
		//print_r($dbc);
		// echo 'status'.mysqli_ping($dbc);
		// return 'allow';
	}

	function logout(){
		//require_once('config.php');
		//session_start();
		// remove all session variables
		session_unset(); 
		$_SESSION = array();
		// get session parameters 
		$params = session_get_cookie_params();
		// Delete the actual cookie. 
		setcookie(session_name(),'', time() - 42000, $params["path"], $params["domain"], $params["secure"], $params["httponly"]);
		// destroy the session 
		session_destroy();
		require_once('config.php');
		$dbc = connect();
		mysqli_close($dbc);
		ob_start();
		echo "<script>location.assign('login.php?result=logout success')</script>";
		//header('Location : ../login.php?result=logout success');
		ob_end_flush();
		exit();
		}


		function hello(){
			echo "hello";
		}
 ?>