<!DOCTYPE html>
<html>
<html lang="en">
<head>
	<title>	The Holy Quran | Sign Up</title>
	<meta charset="utf-8">
	<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- *****Style Sheets***** -->
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/logIn.css">
	<!-- *****Scripts***** -->
	<script src="js/jquery-2.1.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/script.js"></script>    

</head>
    <body style="background-color: #EDDABC;">
<!-- ***********************************************HEADER**************************************************** -->
<header>
	<div class="container-fluid header-outer-div">
		<div class="container header-inner-div">
			<div class="logo">
				<a href="index.php"><img class="logo-img img-responsive" src="images/logo1.png" width="100" height="100"></a>
					<span class="arabic" dir="rtl" lang="ar"><span class="arabic-text">القران الکریم</span></span>
			</div>
		</div>
	</div>
</header>
<div class="container-fluid">
	<div class="container"><br>
		
			<?php 
			if (isset($_GET['result'])) {
				$result = $_GET['result'];
				echo '<div class="error-panel">
						<div class="error-form">';
				echo "<span class='text-center bg-danger text-danger'>".$result."</span>";
				echo "	</div>
					</div><br>";	
			}  
			?>
		<div class="login-panel">
			<!-- <div class="login-form">djdkjdkj</div> -->
			<div class="login-form">
				<form action="http://localhost/php_learning/theHolyQuran/files/process_registration.php" 
				method="POST" id="registerFrm">
					<fieldset>
						<legend>			
							<span>
							<?php if (isset($_GET['result'])) {
	 								$result = $_GET['result'];
	 								if ($result == 'true') {
	 									echo '<span class = "text-success">Your Registration Is Sucessfull</span>';
	 								}
	 								else{
	 								echo'<button class="reloadBtn btn-primary" title="Click To Reload Form" onclick="window.location.href = location.pathname;"><span class="reloadIcon glyphicon glyphicon-refresh text-center"></span></button><br>	';
	 								// echo "<span class='text-danger'>".$result."</span>";
	 								}
	 							}?></span>
	 							<h3 class="text-center">Create An Account</h3>
	 					</legend>
						<div class="form-group">
							<label>Full Name</label>
							<input type="text" name="full_name" title="Your Name" placeholder="Your Name"
							required class="form-control" 
							value="<?php if (isset($_GET['full_name'])) {
								echo $_GET['full_name'];
								}?>" />
						</div>

						<div class="form-group">
							<label>User Name</label>
							<input type="text" name="user_name" title="Your User Name" placeholder="Your User Name" required class="form-control" value="<?php if (isset($_GET['user_name'])) {
								echo $_GET['user_name'];
								}?>"/>
						</div>

						<div class="form-group">
							<label>Password</label>
							<input type="password" name="user_password" title="Your Password" 
							placeholder="Your Password" required class="form-control" />
						</div>

						<div class="form-group">
							<label>E-Mail</label>
							<input type="text" name="user_email" title="Your E-Mail" 
							placeholder="Your E-Mail" required class="form-control" 
							value="<?php if (isset($_GET['user_email'])) {
								echo $_GET['user_email'];
								}?>"/>
						</div>	

						<div class="form-group">
							<input type="submit" name="signUpBtn" class="login-btn" value="Sign Up" />
						</div>
					</fieldset>
						<legend></legend>
					<div class="text-center">	
						Already Have An Account ? <a href="login.php">Login Here</a>
					</div>
				</form>
		 	
			</div>
		</div>
	</div>
</div><br>
<div class="container-fluid" style="background-color: #112E44;"><br>
	<div class="container footter">
		<footer>
			Developed By Soleh Firdous Asime 
			<br> Email : soleh.asmie@gmail.com 
			<br> Phone : +91-9018-352236
		</footer> 
	</div><br>
</div>
       
</body>
</html>
