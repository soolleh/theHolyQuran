<!DOCTYPE html>
<html>
<html lang="en">
<head>
	<title>	The Holy Quran</title>
	<meta charset="utf-8">
	<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- *****Style Sheets***** -->
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/styles.css">
	<!-- *****Scripts***** -->
	<script src="js/jquery-2.1.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/script.js"></script>    

</head>
<body>

 <!-- ********************************************** Header **********************************************-->
<header>
	<div class="container-fluid header-outer-div">
		<div class="container header-inner-div">
			<div class="logo">
				<a href="index.php"></a><img class="logo-img img-responsive" src="images/logo1-lg.png">
					<span class="arabic" dir="rtl" lang="ar">القران الکریم</span>
					<span class="account">
						<a href="register.php">Sign-Up</a> 
						<a href="login.php">Log In</a> 
					</span>
			</div>
		</div>
	</div>
</header>
	
</body>
</html>
